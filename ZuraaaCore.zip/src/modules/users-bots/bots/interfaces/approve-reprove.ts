export default interface ApproveReprove {
  type: string
}
