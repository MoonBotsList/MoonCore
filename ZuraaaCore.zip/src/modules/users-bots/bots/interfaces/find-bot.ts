export default interface FindBot {
  search: string
  type: string
  page: string
  limit: string
  tags: string | null
}
