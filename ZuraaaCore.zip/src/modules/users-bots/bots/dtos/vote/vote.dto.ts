export class VoteDto {
  'g-recaptcha-response'!: string
}
