export enum ReportTopic {
  usoIndevidoDeDados = 'Uso indevido de dados',
  spam = 'Spam',
  massDM = 'MassDM',
  botDeBaixaQualidade = 'Bot de baixa qualidade',
  vazamentoDeToken = 'Vazamento de Token',
  outro = 'Outro'
}
