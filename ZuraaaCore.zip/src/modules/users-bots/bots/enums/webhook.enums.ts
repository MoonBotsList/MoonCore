export enum WebhookTypes {
  Disabled,
  Discord,
  Server
}
