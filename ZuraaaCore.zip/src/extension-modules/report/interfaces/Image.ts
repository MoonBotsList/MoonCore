export default interface Image {
  type: string
  data: Buffer
}
