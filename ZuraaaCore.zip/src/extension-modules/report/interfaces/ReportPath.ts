export interface ReportPath {
  id: number
  fileName: string
}
